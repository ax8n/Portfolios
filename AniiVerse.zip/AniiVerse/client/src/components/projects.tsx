import { Card } from "@/components/ui/card";
import { ExternalLink, Sparkles } from "lucide-react";

const projects = [
  {
    id: 1,
    title: "NeuroVisuals",
    description: "3-point base for vision AI with brain imaging",
    tags: ["AI", "Computer Vision", "Neural Networks"],
    gradient: "from-primary/20 to-accent/20",
  },
  {
    id: 2,
    title: "Devid AI",
    description: "Advanced AI model framework for creative applications",
    tags: ["Machine Learning", "AI Framework"],
    gradient: "from-secondary/20 to-primary/20",
  },
  {
    id: 3,
    title: "D3YPIO AI",
    description: "Integrated deep learning pipeline for data synthesis",
    tags: ["Deep Learning", "Data Science"],
    gradient: "from-accent/20 to-secondary/20",
  },
  {
    id: 4,
    title: "EXYND AI",
    description: "Experimental AI interface for extended reality",
    tags: ["XR", "AI Interface", "Innovation"],
    gradient: "from-primary/20 to-secondary/20",
  },
  {
    id: 5,
    title: "CryptoFlow",
    description: "Blockchain visualization and analytics dashboard",
    tags: ["Blockchain", "Analytics", "Web3"],
    gradient: "from-secondary/20 to-accent/20",
  },
  {
    id: 6,
    title: "BUCSEDSUIT",
    description: "Cybersecurity penetration testing framework",
    tags: ["Security", "DevOps", "Tools"],
    gradient: "from-accent/20 to-primary/20",
  },
];

export function Projects() {
  return (
    <section
      id="projects"
      className="scroll-section py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-transparent via-card/20 to-transparent"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
            <Sparkles className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">Portfolio</span>
          </div>

          <h2
            className="text-4xl md:text-5xl font-orbitron font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent"
            data-testid="text-projects-title"
          >
            PROJECTS
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A collection of innovative projects pushing the boundaries of
            technology
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <Card
              key={project.id}
              className="group relative overflow-visible border-primary/10 bg-card/40 backdrop-blur-sm hover:border-primary/50 transition-all duration-500 cursor-pointer hover-elevate"
              style={{
                boxShadow: "0 0 20px rgba(0, 255, 255, 0.05)",
                animationDelay: `${index * 0.1}s`,
              }}
              data-testid={`card-project-${project.id}`}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />

              <div className="relative p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3
                    className="text-xl font-orbitron font-bold text-foreground group-hover:text-primary transition-colors duration-300"
                    data-testid={`text-project-title-${project.id}`}
                  >
                    {project.title}
                  </h3>
                  <ExternalLink className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-all duration-300" />
                </div>

                <p
                  className="text-muted-foreground mb-6 leading-relaxed"
                  data-testid={`text-project-description-${project.id}`}
                >
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs rounded-full bg-primary/10 text-primary border border-primary/20 font-medium"
                      data-testid={`badge-tag-${tag.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div
                className="absolute inset-0 border-2 border-primary/0 group-hover:border-primary/50 rounded-lg transition-all duration-500 pointer-events-none"
                style={{
                  boxShadow:
                    "0 0 0 rgba(0, 255, 255, 0), 0 0 40px rgba(0, 255, 255, 0)",
                }}
              />
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
