import { Button } from "@/components/ui/button";
import { Code2, Sparkles, Zap, Cpu, Boxes, Rocket } from "lucide-react";

const experiments = [
  {
    id: 1,
    name: "Code Playground",
    icon: Code2,
    gradient: "from-primary to-accent",
  },
  {
    id: 2,
    name: "Neural Canvas",
    icon: Cpu,
    gradient: "from-accent to-secondary",
  },
  {
    id: 3,
    name: "Quantum Viz",
    icon: Zap,
    gradient: "from-secondary to-primary",
  },
  {
    id: 4,
    name: "3D Experiments",
    icon: Boxes,
    gradient: "from-primary to-secondary",
  },
  {
    id: 5,
    name: "AI Playground",
    icon: Sparkles,
    gradient: "from-accent to-primary",
  },
  {
    id: 6,
    name: "Launch Lab",
    icon: Rocket,
    gradient: "from-secondary to-accent",
  },
];

export function Labs() {
  return (
    <section id="labs" className="scroll-section py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/20">
            <Sparkles className="w-4 h-4 text-secondary" />
            <span className="text-sm text-secondary font-medium">
              Experiments
            </span>
          </div>

          <h2
            className="text-4xl md:text-5xl font-orbitron font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent"
            data-testid="text-labs-title"
          >
            LABS
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experimental tools and creative playgrounds where ideas come to life
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {experiments.map((experiment) => {
            const Icon = experiment.icon;
            return (
              <Button
                key={experiment.id}
                variant="outline"
                className="group relative h-auto py-6 px-6 border-primary/20 hover:border-primary/50 bg-card/40 backdrop-blur-sm transition-all duration-500"
                style={{
                  boxShadow: "0 0 20px rgba(0, 255, 255, 0.05)",
                }}
                data-testid={`button-lab-${experiment.id}`}
              >
                <div className="flex items-center gap-4 w-full">
                  <div
                    className={`p-3 rounded-lg bg-gradient-to-br ${experiment.gradient} opacity-20 group-hover:opacity-40 transition-opacity duration-300`}
                  >
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <span className="font-orbitron font-medium text-foreground group-hover:text-primary transition-colors duration-300">
                    {experiment.name}
                  </span>
                </div>

                <div
                  className="absolute inset-0 border-2 border-transparent group-hover:border-primary/30 rounded-lg transition-all duration-500 pointer-events-none"
                  style={{
                    boxShadow:
                      "inset 0 0 0 rgba(0, 255, 255, 0), inset 0 0 20px rgba(0, 255, 255, 0)",
                  }}
                />
              </Button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
