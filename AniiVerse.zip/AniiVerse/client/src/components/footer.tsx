import { Github, Linkedin, Twitter, Zap, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Footer() {
  const socialLinks = [
    { id: 1, name: "GitHub", icon: Github, url: "#" },
    { id: 2, name: "LinkedIn", icon: Linkedin, url: "#" },
    { id: 3, name: "Twitter", icon: Twitter, url: "#" },
  ];

  return (
    <footer
      id="footer"
      className="relative py-12 px-4 sm:px-6 lg:px-8 border-t border-border/50 bg-gradient-to-b from-transparent to-card/30"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start mb-2">
              <span
                className="text-2xl font-orbitron font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent"
                style={{
                  textShadow: "0 0 20px rgba(0, 255, 255, 0.3)",
                }}
              >
                Anii
              </span>
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <p className="text-muted-foreground text-sm" data-testid="text-copyright">
              © 2025 Anii. All rights reserved.
            </p>
          </div>

          <div className="flex items-center gap-4">
            {socialLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Button
                  key={link.id}
                  variant="ghost"
                  size="icon"
                  className="group relative border border-primary/20 hover:border-primary/50 transition-all duration-300"
                  data-testid={`button-social-${link.name.toLowerCase()}`}
                >
                  <Icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                  <div
                    className="absolute inset-0 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    style={{
                      boxShadow: "0 0 20px rgba(0, 255, 255, 0.3)",
                    }}
                  />
                </Button>
              );
            })}
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border/30 text-center">
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
            Built with creativity, powered by code
            <Sparkles className="w-4 h-4 text-primary" />
          </p>
        </div>
      </div>
    </footer>
  );
}
