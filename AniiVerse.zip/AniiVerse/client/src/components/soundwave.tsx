import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Pause, Volume2 } from "lucide-react";

export function Soundwave() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    let animationFrame: number;
    let offset = 0;

    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const bars = 80;
      const barWidth = canvas.width / bars;
      const centerY = canvas.height / 2;

      for (let i = 0; i < bars; i++) {
        const multiplier = isPlaying ? 1 : 0.3;
        const height =
          (Math.sin((i + offset) * 0.3) * 30 +
            Math.sin((i + offset) * 0.5) * 20 +
            Math.sin((i + offset) * 0.7) * 15 +
            20) *
          multiplier;

        const progress = i / bars;
        const hue = 180 + progress * 90;
        
        const gradient = ctx.createLinearGradient(0, centerY - height, 0, centerY + height);
        gradient.addColorStop(0, `hsla(${hue}, 100%, 50%, 0.8)`);
        gradient.addColorStop(0.5, `hsla(${hue + 30}, 80%, 60%, 0.9)`);
        gradient.addColorStop(1, `hsla(${hue}, 100%, 50%, 0.8)`);

        ctx.fillStyle = gradient;
        ctx.shadowBlur = 20;
        ctx.shadowColor = `hsla(${hue}, 100%, 50%, 0.5)`;
        ctx.fillRect(
          i * barWidth,
          centerY - height / 2,
          barWidth - 1,
          height
        );
      }

      if (isPlaying) {
        offset += 0.15;
      }
      animationFrame = requestAnimationFrame(draw);
    }

    draw();

    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [isPlaying]);

  return (
    <section id="soundwave" className="scroll-section py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <Card
          className="relative overflow-hidden border-primary/20 bg-card/40 backdrop-blur-xl"
          style={{
            boxShadow:
              "0 0 40px rgba(0, 255, 255, 0.1), inset 0 0 40px rgba(0, 255, 255, 0.05)",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 pointer-events-none" />
          
          <div className="relative p-8 md:p-12">
            <div className="flex flex-col md:flex-row gap-8 items-center">
              <div className="w-full md:w-1/3">
                <h2
                  className="text-2xl md:text-3xl font-orbitron font-bold mb-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"
                  data-testid="text-soundwave-title"
                >
                  Anii's Soundwave
                </h2>
                <p
                  className="text-lg text-secondary font-medium mb-6"
                  data-testid="text-soundwave-subtitle"
                >
                  The Ethereal Flow
                </p>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Frequency</p>
                    <p className="text-lg font-orbitron text-foreground">
                      432 Hz
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">BPM</p>
                    <p className="text-lg font-orbitron text-foreground">120</p>
                  </div>

                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-full mt-6 border-primary/50 hover:border-primary hover:bg-primary/10 transition-all duration-300"
                    style={{
                      boxShadow: isPlaying
                        ? "0 0 20px rgba(0, 255, 255, 0.3)"
                        : "none",
                    }}
                    data-testid="button-play-pause"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-5 h-5 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Play
                      </>
                    )}
                  </Button>
                </div>
              </div>

              <div className="w-full md:w-2/3">
                <div className="relative">
                  <canvas
                    ref={canvasRef}
                    className="w-full h-64 md:h-80 rounded-lg"
                    data-testid="canvas-soundwave"
                  />
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-card/50 to-transparent rounded-lg" />
                </div>

                <div className="flex items-center justify-between mt-6 text-sm text-muted-foreground">
                  <span>0:00</span>
                  <Volume2 className="w-5 h-5" />
                  <span>3:47</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
