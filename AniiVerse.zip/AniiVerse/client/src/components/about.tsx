import { Button } from "@/components/ui/button";
import { Code2, Sparkles } from "lucide-react";

export function About() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="about"
      className="scroll-section py-20 px-4 sm:px-6 lg:px-8"
    >
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
          <Sparkles className="w-4 h-4 text-primary" />
          <span className="text-sm text-primary font-medium">About Me</span>
        </div>

        <h2
          className="text-3xl md:text-4xl lg:text-5xl font-orbitron font-bold mb-6 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent"
          data-testid="text-about-title"
        >
          Crafting Digital Experiences
        </h2>

        <p
          className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8"
          data-testid="text-about-description"
        >
          I craft immersive digital experiences with a passion for innovative
          design and robust development. My journey as a creative technologist
          blends stunning visuals with cutting-edge code, building everything
          from interactive UIs to AI-powered tools. Every project is an
          opportunity to push boundaries and create something extraordinary.
        </p>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <div className="px-6 py-3 rounded-lg bg-card/60 backdrop-blur-sm border border-primary/20">
            <p className="text-sm text-muted-foreground mb-1">Specialty</p>
            <p className="font-orbitron text-primary">Full-Stack Development</p>
          </div>
          <div className="px-6 py-3 rounded-lg bg-card/60 backdrop-blur-sm border border-accent/20">
            <p className="text-sm text-muted-foreground mb-1">Focus</p>
            <p className="font-orbitron text-accent">AI & Creative Tech</p>
          </div>
          <div className="px-6 py-3 rounded-lg bg-card/60 backdrop-blur-sm border border-secondary/20">
            <p className="text-sm text-muted-foreground mb-1">Passion</p>
            <p className="font-orbitron text-secondary">Innovation</p>
          </div>
        </div>

        <Button
          variant="outline"
          size="lg"
          onClick={() => scrollToSection("labs")}
          className="group border-primary/50 hover:border-primary hover:bg-primary/10 transition-all duration-300"
          style={{
            boxShadow: "0 0 20px rgba(0, 255, 255, 0.2)",
          }}
          data-testid="button-labs"
        >
          <Code2 className="w-5 h-5 mr-2 group-hover:animate-pulse" />
          <span className="font-orbitron">Explore LABS</span>
        </Button>
      </div>
    </section>
  );
}
