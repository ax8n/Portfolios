# Anii's Portfolio Website

## Overview

This is a modern, futuristic portfolio website for Anii, a developer and creator. The application showcases projects, experiments, and creative work through an immersive cyberpunk-inspired interface with glassmorphism effects, neon glows, and animated particle backgrounds. Built as a single-page application with smooth scrolling navigation between sections (Home, Work, Blog, Labs, Contact).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for component-based UI development
- **Vite** as the build tool and development server for fast hot module replacement
- **Wouter** for lightweight client-side routing (instead of React Router)
- Choice rationale: Vite provides superior developer experience with instant server start and fast HMR compared to webpack-based solutions

**Styling System**
- **Tailwind CSS** with custom design system configuration
- **shadcn/ui** component library (New York style variant) for pre-built, accessible UI primitives
- **Custom CSS variables** for theming with dark mode as primary design
- **Design approach**: Reference-based modern futuristic tech UI with cyberpunk aesthetics
- Color palette: Deep space black background (#0A0A0F) with cyan, purple, and blue neon accents
- Typography: Poppins (body), Orbitron (headings/logo), Inter (technical sections)

**Animation & Visual Effects**
- **GSAP (GreenSock)** with ScrollTrigger plugin for scroll-based animations
- **Canvas-based particle systems** for hero background effects
- **Glassmorphism**: backdrop-blur with subtle overlays for card components
- **Neon glow effects**: Multi-layer box-shadow with colored blur
- Choice rationale: GSAP provides professional-grade animation performance and fine-grained control over complex scroll-triggered sequences

**State Management**
- **TanStack Query (React Query)** for server state management and caching
- Custom query client configuration with disabled refetching (staleTime: Infinity)
- Choice rationale: Separates server state from client state, provides automatic background refetching and caching without additional boilerplate

**UI Component Organization**
- Atomic component structure with dedicated UI component library under `@/components/ui`
- Path aliases configured: `@/` (client/src), `@shared/` (shared), `@assets/` (attached_assets)
- Radix UI primitives for accessibility-compliant base components (dialogs, dropdowns, tooltips, etc.)

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript running on Node.js
- HTTP server creation using native Node.js `http` module
- Custom middleware for request logging with duration tracking
- Choice rationale: Express provides minimal, unopinionated server framework suitable for API-focused applications

**Development vs Production**
- Development: Vite middleware integration for HMR and SSR template serving
- Production: Static file serving from dist/public directory
- Build process: Separate client (Vite) and server (esbuild) compilation

**Storage Layer**
- **In-memory storage implementation** (MemStorage class) for development/testing
- Interface-based design (IStorage) allows swapping to persistent storage
- Current implementation: User management with UUID-based IDs
- Choice rationale: Interface abstraction enables easy migration to database without changing application code

### External Dependencies

**Database Configuration**
- **Drizzle ORM** configured for PostgreSQL dialect
- **@neondatabase/serverless** driver for Neon database connectivity
- Schema definition in `shared/schema.ts` using Drizzle's schema builder
- Migration system configured with output to `./migrations` directory
- Environment variable: `DATABASE_URL` required for database connection
- Choice rationale: Drizzle provides type-safe database operations with minimal runtime overhead and excellent TypeScript integration

**UI Component Libraries**
- **Radix UI** primitives (20+ components including accordion, dialog, dropdown-menu, select, tabs, toast)
- **shadcn/ui** configuration for consistent component styling
- **Lucide React** for icon system
- **cmdk** for command palette functionality
- **embla-carousel-react** for carousel/slider components

**Form Handling**
- **React Hook Form** for form state management
- **@hookform/resolvers** with Zod for schema validation
- **drizzle-zod** for automatic Zod schema generation from Drizzle tables

**Animation Libraries**
- **GSAP** core with ScrollTrigger plugin
- **Framer Motion** (via class-variance-authority for variant-based styling)

**Utility Libraries**
- **clsx** and **tailwind-merge** for conditional class name composition
- **date-fns** for date manipulation
- **nanoid** for ID generation

**Development Tools**
- **Replit-specific plugins**: cartographer (code mapping), dev-banner, runtime-error-modal
- **TypeScript** with strict mode enabled
- **ESM module system** throughout the application

**Session Management**
- **connect-pg-simple** for PostgreSQL-backed session storage (configured but not actively used in current implementation)