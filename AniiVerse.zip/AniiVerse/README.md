# Anii - Developer & Creator Portfolio

A stunning futuristic portfolio website featuring neon animations, glassmorphism effects, and interactive visualizations. Built with modern web technologies to showcase creative projects and experiments.

![Portfolio Preview](attached_assets/1760932108320_1760932473282.jpg)

## Features

### Visual Design
- **Dark Futuristic Theme** - Deep space black background with neon cyan, purple, and blue accents
- **Glassmorphism Effects** - Frosted glass cards with backdrop blur and subtle overlays
- **Neon Glow Animations** - Multi-layered box shadows with colored blur effects
- **Smooth Transitions** - GSAP-powered scroll animations and hover effects

### Interactive Components
- **Animated Hero Section** - Canvas-based particle system with flowing gradient particles
- **Interactive Soundwave** - Real-time audio waveform visualization with play/pause controls
- **Project Gallery** - Showcase of 6 innovative projects with hover effects and neon borders
- **Labs Section** - Experimental tools and creative playgrounds
- **Sticky Navigation** - Glassmorphism navbar with smooth scroll behavior

### Responsive Design
- Fully responsive layout optimized for desktop, tablet, and mobile
- Mobile-first approach with hamburger menu navigation
- Optimized animations and effects for all screen sizes

## Technologies Used

### Frontend
- **React 18** - Component-based UI library
- **TypeScript** - Type-safe development
- **Vite** - Fast build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **GSAP** - Professional-grade animations with ScrollTrigger
- **Canvas API** - Particle effects and waveform visualizations

### UI Components
- **shadcn/ui** - Accessible component primitives
- **Radix UI** - Unstyled, accessible components
- **Lucide React** - Beautiful icon system

### Backend
- **Express.js** - Minimal web server
- **Node.js** - JavaScript runtime

## Getting Started

### Prerequisites
- Node.js 20 or higher
- npm or yarn package manager

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd portfolio
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
.
├── client/                  # Frontend application
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── navbar.tsx  # Sticky navigation
│   │   │   ├── hero.tsx    # Hero with particles
│   │   │   ├── soundwave.tsx # Audio visualization
│   │   │   ├── about.tsx   # About section
│   │   │   ├── projects.tsx # Project gallery
│   │   │   ├── labs.tsx    # Experiments section
│   │   │   └── footer.tsx  # Footer with socials
│   │   ├── pages/
│   │   │   └── home.tsx    # Main page
│   │   ├── App.tsx         # Root component
│   │   └── index.css       # Global styles
│   └── index.html          # HTML template
├── server/                  # Backend server
│   └── index.ts            # Express server
├── tailwind.config.ts      # Tailwind configuration
└── package.json            # Dependencies
```

## Customization

### Colors
Edit the color scheme in `client/src/index.css`:
- `--primary`: Neon cyan (180 100% 50%)
- `--secondary`: Purple (270 80% 60%)
- `--accent`: Blue (220 90% 55%)

### Content
Update project data in `client/src/components/projects.tsx`:
```typescript
const projects = [
  {
    id: 1,
    title: "Your Project",
    description: "Project description",
    tags: ["Tag1", "Tag2"],
    gradient: "from-primary/20 to-accent/20",
  },
  // Add more projects...
];
```

### Fonts
Customize typography in `client/index.html`:
- **Orbitron** - Display font for headings
- **Poppins** - Body text
- **Inter** - Technical sections

## Development

### Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

### Key Features to Customize
- **Particle System** - Adjust particle count, speed, and colors in `hero.tsx`
- **Waveform Animation** - Modify frequency and amplitude in `soundwave.tsx`
- **Scroll Animations** - Configure GSAP ScrollTrigger settings in `home.tsx`

## Deployment

This application is optimized for deployment on Replit. To publish:

1. Ensure all changes are saved
2. Click the "Publish" button in Replit
3. Your portfolio will be live at `your-project.replit.app`

## Performance Optimizations

- Canvas animations use `requestAnimationFrame` for smooth 60fps
- GSAP scroll triggers are optimized for minimal reflow
- Images and assets are lazy-loaded
- Tailwind CSS purges unused styles in production

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## License

© 2025 Anii. All rights reserved.

## Acknowledgments

- Design inspiration from cyberpunk and futuristic UI dashboards
- Animation library: [GSAP](https://greensock.com/gsap/)
- Component primitives: [shadcn/ui](https://ui.shadcn.com/)
- Icons: [Lucide React](https://lucide.dev/)
