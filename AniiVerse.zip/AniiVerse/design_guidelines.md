# Design Guidelines for Anii's Portfolio Website

## Design Approach
**Reference-Based Approach**: Modern futuristic tech UI dashboard aesthetic inspired by high-end digital experiences, cyberpunk interfaces, and advanced data visualization platforms.

## Core Design Elements

### A. Color Palette
**Dark Mode (Primary)**
- Background: #0A0A0F (deep space black)
- Primary Neon: Cyan (180 100% 50%)
- Secondary Neon: Purple (270 80% 60%)
- Tertiary Neon: Blue (220 90% 55%)
- Text: White with subtle glow
- Overlay/Glass: rgba(255,255,255,0.05) with backdrop blur

### B. Typography
- Primary Font: Poppins (body text, UI elements)
- Display Font: Orbitron (headings, logo)
- Fallback: Inter (technical sections)
- Hierarchy: Use glowing text effects on headings, normal weight for readability

### C. Layout System
Tailwind spacing: Use units of 4, 8, 12, 16, 20, 24, 32 for consistent vertical rhythm
- Container: max-w-7xl with px-4 to px-8
- Section padding: py-20 desktop, py-12 mobile
- Card spacing: gap-6 to gap-8

### D. Visual Effects
**Glassmorphism**: backdrop-blur-xl with subtle white/colored overlays (5-10% opacity)
**Neon Glow**: box-shadow with multiple layers of colored blur
**Motion Blur**: Subtle blur on moving elements
**Particle Effects**: Flowing gradient lines and animated particles in hero background
**Hover States**: Scale transforms (1.02-1.05), increased glow intensity, smooth transitions

## Component Library

### Navigation
- Sticky header with glassmorphism background blur
- Logo: "Anii ⚡" in neon cyan with glow effect
- Menu items: Home, Work, Blog, Labs, Contact
- Hover animation: Neon glow underline or text glow
- Mobile: Hamburger menu with animated slide-in drawer

### Hero Section
- Full viewport height (min-h-screen)
- Title: "Anii – Developer & Creator" (large, Orbitron font, glowing)
- Subtitle: "I craft immersive digital experiences with creativity, design, and code."
- Animated background: Flowing gradient lines or moving particles (purple/blue/cyan)
- Digital waveform animation behind text (subtle, ambient)
- Fade-in and slide-up entrance animations

### Soundwave Card
- Glassmorphism card with glowing neon edges
- Title: "Anii's Soundwave – The Ethereal Flow"
- Interactive audio waveform visualization syncing to beat
- Soft background blur with gradient glow
- Play/pause controls with neon styling

### About Me Section
- Clean layout with profile description
- Scroll-triggered fade-in animation
- Glowing "LABS" button with neon border and hover pulse effect
- Optional: Small avatar with neon border glow

### Projects Gallery
- Grid layout: 2-3 columns desktop, 1 column mobile
- Project cards: NeuroVisuals, Devid AI, CryptoFlow, etc.
- Glassmorphism card background with neon borders
- Hover effects: Scale up slightly (1.05), intensified glow, smooth transition
- Scroll animation: Stagger slide-in from left/right
- Card content: Project thumbnail, title, description, tech tags

### Labs Section
- Pill-shaped glowing buttons for experiment links
- Small code icons or gradient badges
- Grid or flex layout with gap-4
- Hover: Brightness increase and border glow

### Footer
- Dark background with subtle gradient
- Text: "© 2025 Anii. All rights reserved."
- Social icons: GitHub, LinkedIn, Twitter
- Icon hover: Neon glow effect and scale transform
- Responsive layout

## Animations & Interactions
- **Page Load**: Smooth fade-in transitions using GSAP
- **Scroll Animations**: Fade-in, slide-up for sections as they enter viewport
- **Hover**: Scale transforms, glow intensity increase, smooth 300ms transitions
- **Parallax**: Subtle parallax scrolling on hero background elements
- **Smooth Scrolling**: Enable smooth scroll behavior site-wide
- **Cursor Trail** (Bonus): Floating neon cursor effect with particle trail

## Responsive Behavior
- Desktop: Full layouts with multi-column grids
- Tablet (md): 2-column layouts, adjusted spacing
- Mobile: Single column stack, hamburger menu, optimized touch targets
- All animations and effects must perform smoothly on mobile devices

## Special Features
- **Animated Intro Loader**: Logo appears first with neon fade-in effect
- **Dark/Light Mode Toggle** (Bonus): Switch maintaining neon aesthetic
- **Interactive Elements**: Waveform reacts to audio, particles respond to mouse movement
- **3D-Style Effects**: Use Three.js or CSS transforms for depth illusion

## Images
This design uses minimal photography, focusing instead on:
- Abstract gradient backgrounds and particle animations
- Custom-generated waveform visualizations
- Neon UI elements and glowing effects
- Optional: Small profile avatar in About section
- Project thumbnails in Projects gallery (can be mockups or screenshots with neon borders)

**No large hero image** - the hero uses animated gradients and particle effects instead.